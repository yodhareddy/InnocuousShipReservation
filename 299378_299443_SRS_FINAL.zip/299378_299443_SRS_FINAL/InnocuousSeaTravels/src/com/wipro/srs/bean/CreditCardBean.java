package com.wipro.srs.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.validation.constraints.NotNull;

import javax.validation.constraints.Size;



@Entity
@Table(name="SRS_TBL_CreditCard")
public class CreditCardBean {

	@Id

	@Size(min=16,max=16,message="credit card number must be 16 chars")
	private String creditCardNumber;

	@Size(min=10,max=10,message="MM/dd/yyyy")
	private String validFrom;
	
	@Size(min=10,max=10,message="MM/dd/yyyy")
	private String validTo;
	@NotNull
	private double balance;
	private String userID;
	public String getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public String getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}
	public String getValidTo() {
		return validTo;
	}
	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
}
