package com.wipro.srs.bean;


import javax.persistence.Entity;


import javax.persistence.Id;


import javax.persistence.Table;
import javax.validation.constraints.NotNull;


import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
//@SequenceGenerator(name="seq",sequenceName="SRS_SEQ_SHIP_ID")
@Entity
@Table(name="SRS_TBL_Ship")
public class ShipBean {
	
@Id
@NotEmpty
//@GeneratedValue(strategy=GenerationType.AUTO,generator="seq")

private String shipID;
@NotEmpty(message="shipName cannot be empty")
private String shipName;
@NotNull
@Range(min=1,max=1000,message="Enter seating capacity between 1 and 1000")
private int seatingCapacity;
@NotNull
@Range(min=0,max=1000,message="Enter reservation capacity between 0 and 1000")
private int reservationCapacity;
public String getShipID() {
	return shipID;
}
public void setShipID(String shipID) {
	this.shipID = shipID;
}
public String getShipName() {
	return shipName;
}
public void setShipName(String shipName) {
	this.shipName = shipName;
}
public int getSeatingCapacity() {
	return seatingCapacity;
}
public void setSeatingCapacity(int seatingCapacity) {
	this.seatingCapacity = seatingCapacity;
}
public int getReservationCapacity() {
	return reservationCapacity;
}
public void setReservationCapacity(int reservationCapacity) {
	this.reservationCapacity = reservationCapacity;
}
}
