package com.wipro.srs.bean;

import javax.persistence.Entity;


import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
//@SequenceGenerator(name="seq",sequenceName="SRS_SEQ_ROUTE_ID")
@Entity
@Table(name="SRS_TBL_Route")
public class RouteBean {

@Id
@NotEmpty
//@GeneratedValue(strategy=GenerationType.AUTO,generator="seq")
private String routeID;
@NotEmpty(message="source cannot be empty")
private String source;
@NotEmpty(message="destination cannot be empty")
private String destination;
@NotEmpty(message="travel duration cannot be empty")
@Pattern(regexp="[0-9]*[.][0-9]*",message="Duration must be in decimals")
private String travelDuration;
@NotNull(message="fare can't be empty")
@Range(min=1,max=10000)
private double fare;
public String getRouteID() {
	return routeID;
}
public void setRouteID(String routeID) {
	this.routeID = routeID;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public String getTravelDuration() {
	return travelDuration;
}
public void setTravelDuration(String travelDuration) {
	this.travelDuration = travelDuration;
}
public double getFare() {
	return fare;
}
public void setFare(double fare) {
	this.fare = fare;
}

}
