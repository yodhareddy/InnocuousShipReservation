package com.wipro.srs.bean;

import java.util.Date;

import javax.persistence.Entity;


import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

//@SequenceGenerator(name="seq",sequenceName="SRS_SEQ_RESERVATION_ID")
@Entity
@Table(name="SRS_TBL_Reservation")
public class ReservationBean {
@Id
//@GeneratedValue(strategy=GenerationType.AUTO,generator="seq")
@NotEmpty(message="Reservation ID cannot be null")
private String reservationID;
private String scheduleID;
private String userID;
@NotNull
private Date bookingDate;
@NotNull
private Date journeyDate;
@NotNull(message="enter some seats")
@Range(min=1,max=5,message="no of seats must be between 1 and 5")
private int noOfSeats;
@NotNull
private double totalFare;
private String bookingStatus;
public String getReservationID() {
	return reservationID;
}
public void setReservationID(String reservationID) {
	this.reservationID = reservationID;
}
public String getScheduleID() {
	return scheduleID;
}
public void setScheduleID(String scheduleID) {
	this.scheduleID = scheduleID;
}
public String getUserID() {
	return userID;
}
public void setUserID(String userID) {
	this.userID = userID;
}
public Date getBookingDate() {
	return bookingDate;
}
public void setBookingDate(Date bookingDate) {
	this.bookingDate = bookingDate;
}
public Date getJourneyDate() {
	return journeyDate;
}
public void setJourneyDate(Date journeyDate) {
	this.journeyDate = journeyDate;
}
public int getNoOfSeats() {
	return noOfSeats;
}
public void setNoOfSeats(int noOfSeats) {
	this.noOfSeats = noOfSeats;
}
public double getTotalFare() {
	return totalFare;
}
public void setTotalFare(double totalFare) {
	this.totalFare = totalFare;
}
public String getBookingStatus() {
	return bookingStatus;
}
public void setBookingStatus(String bookingStatus) {
	this.bookingStatus = bookingStatus;
}

}
