package com.wipro.srs.bean;


import javax.persistence.Entity;


import javax.persistence.Id;
import javax.persistence.IdClass;

import javax.persistence.Table;

import javax.validation.constraints.NotNull;


import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@IdClass(value=PassengerPK.class)
@Table(name="SRS_TBL_Passenger")
public class PassengerBean {
	@Id
	private String reservationID;
	@NotEmpty(message="Schedule ID cannot be empty")
	private String scheduleID;
	@Id
	@NotEmpty
	private String name;
	@NotNull
	@Range(max=100,min=1)
	private int age;
	@NotEmpty
	private String gender;
	public PassengerBean()
	{
		super();
	}
	public PassengerBean(String reservationID,String scheduleID,String name,int age,String gender)
	{
		this.reservationID=reservationID;
		this.age=age;
		this.scheduleID=scheduleID;
		this.name=name;
		this.gender=gender;
	}
	public String getReservationID() {
		return reservationID;
	}
	public void setReservationID(String reservationID) {
		this.reservationID = reservationID;
	}
	public String getScheduleID() {
		return scheduleID;
	}
	public void setScheduleID(String scheduleID) {
		this.scheduleID = scheduleID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}
