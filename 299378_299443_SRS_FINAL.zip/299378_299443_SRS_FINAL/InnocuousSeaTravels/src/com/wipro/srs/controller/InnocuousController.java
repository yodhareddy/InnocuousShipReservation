package com.wipro.srs.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.srs.bean.CredentialsBean;
import com.wipro.srs.bean.CreditCardBean;
import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.bean.ProfileBean;
import com.wipro.srs.bean.ReservationBean;
import com.wipro.srs.bean.RouteBean;
import com.wipro.srs.bean.ScheduleBean;
import com.wipro.srs.bean.ShipBean;
import com.wipro.srs.service.Administrator;
import com.wipro.srs.util.Authentication;
//import com.wipro.srs.util.User;
import com.wipro.srs.util.User2;

@Controller
public class InnocuousController {

	@Autowired
	private Administrator shipAdministrator;
	
	@Autowired
	private User2 user2;

	@Autowired
	private Authentication authentication;
	
	
	
	@RequestMapping(value="/start")
	public String doStart(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,HttpSession session)
	{
		session.setAttribute("login","no");
		return "login";
	}

	@RequestMapping(value="/view")
	public String doView(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,HttpSession session)
	{
		session.setAttribute("login","no");
		return "viewmenu";
	}
	
	@RequestMapping(value="/returnBack")
	public String doReturn(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,@ModelAttribute ScheduleBean scheduleBean,HttpSession session,Map<String,Object> map)
	{
		ArrayList<RouteBean> routeBean=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("source",routeBean);
		map.put("destination",routeBean);
		return "user";
	}
	@RequestMapping(value="/Back")
	public String doReturns(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,@ModelAttribute ScheduleBean scheduleBean,@ModelAttribute PassengerBean passengerBean,HttpSession session)
	{
		return "admin";
	}
	@RequestMapping(value="/changePassword")
	public String doChangePassword(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean)
	{
		return "newpassword";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String doLogin(@Valid @ModelAttribute CredentialsBean credentialsBean,BindingResult result,@ModelAttribute ProfileBean profileBean,@ModelAttribute ScheduleBean scheduleBean,Map<String,Object> map,HttpSession session)
	{
		if(result.hasErrors()){
			return "login";}
		if(session.getAttribute("login").equals("yesAdmin"))
		{
			return "admin";
		}
		if(session.getAttribute("login").equals("yesUser"))
		{
			return "user";
		}
		String status=user2.login(credentialsBean);
		if("A".equals(status)||"C".equals(status))
		{
			int loginStatus=1;
			boolean change=authentication.changeLoginStatus(credentialsBean, loginStatus);
			
			if(!change)
			{
				map.put("already","already");
				return "login";
			}
		}
		if("A".equals(status))
		{
			session.setAttribute("userID",credentialsBean.getUserID());
	
			if(credentialsBean.getPassword().equals("admin"))
			{
				return "newpasswordAdmin";
			}
			//session.setAttribute("userID","userID");
			
			
			session.setAttribute("password",credentialsBean.getPassword());
			session.setAttribute("login","yesAdmin");
			return "admin";
		}
		if("C".equals(status))
		{
			//session.setAttribute("userID","userID");
			session.setAttribute("userID",credentialsBean.getUserID());
			
			session.setAttribute("login","yesUser");
			ArrayList<RouteBean> routeBean=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
			map.put("source",routeBean);
			map.put("destination",routeBean);
			return "user";
		}
		if("FAIL".equals(status)){
			map.put("fail","fail");}
		if("INVALID".equals(status)){
			map.put("invalid","invalid");}
		return null;
	}
	
	
	
	
	
	
	
	@RequestMapping(value="/doregister",method=RequestMethod.POST)
	public String Register(@ModelAttribute CredentialsBean credentialsBean,@Valid @ModelAttribute ProfileBean profileBean,BindingResult result,Map<String,Object> map,HttpSession session)
	{
		if(result.hasErrors()){
			return "register";}
		if(session.getAttribute("status").equals("new"))
		{
			return "login";
		}
		
		
		String registration=user2.register(profileBean);
		if("FAIL".equals(registration))
		{
			return "fail";
		}
		map.put("userID",profileBean.getUserID());
		map.put("registered","registered");
		session.setAttribute("status","new");
		return "login";
	}
	@RequestMapping(value="/register")
	public String doRegister(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,HttpSession session)
	{	
		
		session.setAttribute("status","old");
		
		return "register";
	}
	@RequestMapping(value="/ship")
	public String ship(@ModelAttribute ShipBean shipBean,Map<String,Object> map)
	{
		ArrayList<ShipBean> ships=(ArrayList<ShipBean>) shipAdministrator.viewByAllShips();
		
		map.put("ships",ships);
		return "ship";
	}
	@RequestMapping(value="/addShip",method=RequestMethod.POST)
	public String addShip(@Valid @ModelAttribute ShipBean shipBean,BindingResult result,Map<String,Object> map)
	{
		ArrayList<ShipBean> ships=(ArrayList<ShipBean>) shipAdministrator.viewByAllShips();
		map.put("ships",ships);
		if(result.hasFieldErrors("shipName")||result.hasFieldErrors("reservationCapacity")||result.hasFieldErrors("seatingCapacity"))
			{return "ship";}
		
		String addStatus=shipAdministrator.addShip(shipBean);
		return "redirect:/ship";
	}
	@RequestMapping(value="/modifyShip",params="deleteShip",method=RequestMethod.POST)
	public String deleteShip(@Valid @ModelAttribute ShipBean shipBean,BindingResult result,Map<String,Object> map)
	{
		ArrayList<ShipBean> ships=(ArrayList<ShipBean>) shipAdministrator.viewByAllShips();
		map.put("ships",ships);
		if(result.hasErrors()){
			return "ship";}
		boolean status=shipAdministrator.updateBalanceShip(shipBean.getShipID());
		int removeStatus=shipAdministrator.removeShip(shipBean);
		return "redirect:/ship";
	}
	@RequestMapping(value="/modifyShip",params="updateShip",method=RequestMethod.POST)
	public String modifyShip(@Valid @ModelAttribute ShipBean shipBean,BindingResult result,Map<String,Object> map)
	{
		ArrayList<ShipBean> ships=(ArrayList<ShipBean>) shipAdministrator.viewByAllShips();
		map.put("ships",ships);
		if(result.hasErrors()){
			return "ship";}
		boolean modify=shipAdministrator.modifyShip(shipBean);
		return "redirect:/ship";
	}
	
	@RequestMapping(value="/route")
	public String route(@ModelAttribute RouteBean routeBean,Map<String,Object> map)
	{
		ArrayList<RouteBean> route=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("route",route);
		return "route";
	}
	@RequestMapping(value="/addRoute",method=RequestMethod.POST)
	public String addShip(@Valid @ModelAttribute RouteBean routeBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("source")||result.hasFieldErrors("destination")||result.hasFieldErrors("travelDuration")||result.hasFieldErrors("fare"))
		{
			
		ArrayList<RouteBean> route=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("route",route);	
			return "route";
		}
		
		String addStatus=shipAdministrator.addRoute(routeBean);
		return "redirect:/route";
	}
	@RequestMapping(value="/modifyRoute",params="deleteRoute",method=RequestMethod.POST)
	public String deleteRoute(@Valid @ModelAttribute RouteBean routeBean,BindingResult result,Map<String,Object> map)
	{
		
		ArrayList<RouteBean> route=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("route",route);
		
		if(result.hasErrors())
		{
			return "route";
		}
		boolean status=shipAdministrator.updateBalanceRoute(routeBean.getRouteID()); 
		int removeStatus=shipAdministrator.removeRoute(routeBean);
		return "redirect:/route";
	}
	@RequestMapping(value="/modifyRoute",params="updateRoute",method=RequestMethod.POST)
	public String modifyRoute(@Valid @ModelAttribute RouteBean routeBean,BindingResult result,Map<String,Object> map)
	{
		ArrayList<RouteBean> route=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("route",route);

		if(result.hasErrors())
		{
			return "route";
		}
		boolean modify=shipAdministrator.modifyRoute(routeBean);
		return "redirect:/route";
	}
	@RequestMapping(value="/schedule")
	public String route(@ModelAttribute ScheduleBean scheduleBean,Map<String,Object> map)
	{
		ArrayList<ScheduleBean> schedule=(ArrayList<ScheduleBean>) shipAdministrator.viewByAllSchedule();
		SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy");
		List<ShipBean> ship=shipAdministrator.viewByAllShips();
		List<RouteBean> route=shipAdministrator.viewByAllRoute();
		for(int index=0;index<schedule.size();index++)
		{
			
			Date forStart=schedule.get(index).getStartDate();
			
			schedule.get(index).setStart(formats.format(forStart));

		}
		map.put("ship",ship);
		map.put("route",route);
		map.put("schedule",schedule);
		return "schedule";
	}
	@RequestMapping(value="/addSchedule",method=RequestMethod.POST)
	public String addSchedule(@Valid @ModelAttribute ScheduleBean scheduleBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("shipID")||result.hasFieldErrors("routeID")||result.hasFieldErrors("startDate"))
		{
			ArrayList<ScheduleBean> schedule=(ArrayList<ScheduleBean>) shipAdministrator.viewByAllSchedule();
			SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy");
			List<ShipBean> ship=shipAdministrator.viewByAllShips();
			List<RouteBean> route=shipAdministrator.viewByAllRoute();
			for(int index=0;index<schedule.size();index++)
			{

				Date forStart=schedule.get(index).getStartDate();
				schedule.get(index).setStart(formats.format(forStart));
				
			}
			map.put("ship",ship);
			map.put("route",route);
			map.put("schedule",schedule);
			return "schedule";
		}
		String addStatus=shipAdministrator.addSchedule(scheduleBean);
		return "redirect:/schedule";
	}
	@RequestMapping(value="/modifySchedule",params="deleteSchedule",method=RequestMethod.POST)
	public String deleteSchedule(@Valid @ModelAttribute ScheduleBean scheduleBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasErrors())
		{
			ArrayList<ScheduleBean> schedule=(ArrayList<ScheduleBean>) shipAdministrator.viewByAllSchedule();
			List<ShipBean> ship=shipAdministrator.viewByAllShips();
			List<RouteBean> route=shipAdministrator.viewByAllRoute();
			
			SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy");
			for(int index=0;index<schedule.size();index++)
			{
				
				Date forStart=schedule.get(index).getStartDate();
				schedule.get(index).setStart(formats.format(forStart));
				
			}
			map.put("ship",ship);
			map.put("route",route);
			map.put("schedule",schedule);
			return "schedule";
		}
		boolean status=shipAdministrator.updateBalanceSchedule(scheduleBean.getScheduleID());
		int removeStatus=shipAdministrator.removeSchedule(scheduleBean);
		return "redirect:/schedule";
	}
	@RequestMapping(value="/modifySchedule",params="updateSchedule",method=RequestMethod.POST)
	public String modifySchedule(@Valid @ModelAttribute ScheduleBean scheduleBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasErrors())
		{
			ArrayList<ScheduleBean> schedule=(ArrayList<ScheduleBean>) shipAdministrator.viewByAllSchedule();
			SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy");
			List<ShipBean> ship=shipAdministrator.viewByAllShips();
			List<RouteBean> route=shipAdministrator.viewByAllRoute();
			for(int index=0;index<schedule.size();index++)
			{

				Date forStart=schedule.get(index).getStartDate();
				schedule.get(index).setStart(formats.format(forStart));
				
			}
			map.put("ship",ship);
			map.put("route",route);
			map.put("schedule",schedule);
			return "schedule";
		}
		boolean modify=shipAdministrator.modifySchedule(scheduleBean);
		return "redirect:/schedule";
	}
	
	
	@RequestMapping(value="/viewbyshipid",method=RequestMethod.GET)
	public String enterShipID(@ModelAttribute ShipBean shipBean)
	{
		return "shipid";
	}
	@RequestMapping(value="/viewbyrouteid",method=RequestMethod.GET)
	public String enterRouteID(@ModelAttribute RouteBean routeBean)
	{
		return "routeid";
	}
	
	@RequestMapping(value="/viewbyscheduleid",method=RequestMethod.GET)
	public String enterScheduleID(@ModelAttribute ScheduleBean scheduleBean)
	{
		return "scheduleid";
	}
	
	
	
	@RequestMapping(value="/viewbyshipiddetail",method=RequestMethod.GET)
	public String enterShipIDdetail(@Valid @ModelAttribute ShipBean shipBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("shipID")){
			return "shipid";}
		ShipBean ship=shipAdministrator.viewByShipId(shipBean.getShipID());
		if(ship==null)
		{
			map.put("noship","noship");
			return "shipid";
		}
		map.put("shipid",ship);
		return "viewbyshipid";
	}
	@RequestMapping(value="/viewbyrouteiddetail",method=RequestMethod.GET)
	public String enterRouteIDdetail(@Valid @ModelAttribute RouteBean routeBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("routeID")){
			return "routeid";}
		RouteBean route=shipAdministrator.viewByRouteId(routeBean.getRouteID());
		if(route==null)
		{
			map.put("noroute","noroute");
			return "routeid";
		}
		map.put("routeid",route);
		return "viewbyrouteid";
	}
	
	@RequestMapping(value="/viewbyscheduleiddetail",method=RequestMethod.GET)
	public String enterScheduleIDdetail(@Valid @ModelAttribute ScheduleBean scheduleBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("scheduleID")){
			return "scheduleid";}
		ScheduleBean schedule=shipAdministrator.viewByScheduleId(scheduleBean.getScheduleID());
		if(schedule==null)
		{
			map.put("noschedule","noschedule");
			return "scheduleid";
		}
		map.put("scheduleid",schedule);
		return "viewbyscheduleid";
	}
	@RequestMapping(value="/viewbyallships",method=RequestMethod.GET)
	public String ships(@ModelAttribute ShipBean shipBean,Map<String,Object> map)
	{
		ArrayList<ShipBean> ship=(ArrayList<ShipBean>) shipAdministrator.viewByAllShips();
		map.put("allships",ship);
		return "viewbyallships";
	}
	
	@RequestMapping(value="/viewbyallroute",method=RequestMethod.GET)
	public String routes(@ModelAttribute RouteBean routeBean,Map<String,Object> map)
	{
		ArrayList<RouteBean> route=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("allroutes",route);
		return "viewbyallroute";
	}
	@RequestMapping(value="/viewbyallschedule",method=RequestMethod.GET)
	public String schedules(@ModelAttribute ScheduleBean scheduleBean,Map<String,Object> map)
	{
		ArrayList<ScheduleBean> schedule=(ArrayList<ScheduleBean>) shipAdministrator.viewByAllSchedule();
		map.put("allschedules",schedule);
		return "viewbyallschedule";
	}
	
	
	
	@RequestMapping(value="/PassengersByShip",method=RequestMethod.GET)
	public String passengers(@Valid @ModelAttribute PassengerBean passengerBean,BindingResult result,Map<String,Object> map)
	{
		if(result.hasFieldErrors("scheduleID")){
			return "passengerById";}
		ArrayList<PassengerBean> passenger=shipAdministrator.viewPassengersByShip(passengerBean.getScheduleID());
		map.put("passengers",passenger);
		return "viewPassengers";
	}
	
	@RequestMapping(value="/viewPassengersByShip")
	public String doPassenger(@ModelAttribute CredentialsBean credentialsBean,@ModelAttribute ProfileBean profileBean,@ModelAttribute ScheduleBean scheduleBean,@ModelAttribute PassengerBean passengerBean,HttpSession session)
	{
		return "passengerById";
	}
	
	
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public String doSearch(@Valid @ModelAttribute ScheduleBean scheduleBean,BindingResult result,HttpServletRequest request,Map<String,Object> map)
	{

		ArrayList<RouteBean> routeBean1=(ArrayList<RouteBean>) shipAdministrator.viewByAllRoute();
		map.put("source",routeBean1);
		map.put("destination",routeBean1);
		if(result.hasFieldErrors("startDate")){
			return "user";}
		String source=request.getParameter("source");
		String destination=request.getParameter("destination");
		ArrayList<ScheduleBean> schedule=new ArrayList<ScheduleBean>();
		ArrayList displayShip=new ArrayList(); 
		ArrayList displayRoute=new ArrayList();
		ArrayList displaySchedule=new ArrayList(); 
		schedule=shipAdministrator.viewScheduleByRoute(source,destination,scheduleBean.getStartDate());
		//if(schedule.size()==0)
		if(schedule.isEmpty())
		{
			map.put("noschedule","noschedule");
			return "user";
		}
		//System.out.println(schedule.get(3).getRouteID());
		for(int i=0;i<schedule.size();i++)
		{
		ShipBean shipBean=shipAdministrator.viewByShipId(schedule.get(i).getShipID());
		
		RouteBean routeBean=shipAdministrator.viewByRouteId(schedule.get(i).getRouteID());
		ScheduleBean schedules=shipAdministrator.viewByScheduleId(schedule.get(i).getScheduleID());
		displaySchedule.add(schedules);
		displayShip.add(shipBean);
		displayRoute.add(routeBean);
		}
		map.put("displaySchedule",displaySchedule);
		map.put("displayShip",displayShip);
		map.put("displayRoute",displayRoute);
		return "searchResults";
	}
	
	@RequestMapping(value="/reservation",method=RequestMethod.POST)
	public String doReserve(@ModelAttribute ReservationBean reservationBean,HttpSession session,@ModelAttribute ScheduleBean scheduleBean)
	{
		
		session.setAttribute("scheduleID",scheduleBean.getScheduleID());
		String sid=(String)session.getAttribute("scheduleID");
		int reservationSeat=shipAdministrator.capacity(sid);
		session.setAttribute("seatss",reservationSeat);
		
		return "reserve";
	}
	
	@RequestMapping(value="/reserve",method=RequestMethod.POST)
	public String reserve(@Valid @ModelAttribute ReservationBean reservationBean,BindingResult result,@ModelAttribute PassengerBean passengerBean,HttpSession session)
	{
		if(result.hasFieldErrors("noOfSeats")){
			return "reserve";}
			session.setAttribute("seats",reservationBean.getNoOfSeats());
		ReservationBean reservation=new ReservationBean();
		int seat=(Integer)session.getAttribute("seats");
		reservation.setNoOfSeats(seat);
		Date bookingDate=new Date();
		reservation.setBookingDate(bookingDate);

		reservation.setUserID((String)session.getAttribute("userID"));
		reservation.setScheduleID((String)session.getAttribute("scheduleID"));
		reservation.setBookingStatus("pending");
		ScheduleBean scheduleBean=shipAdministrator.viewByScheduleId((String)session.getAttribute("scheduleID"));
		reservation.setJourneyDate(scheduleBean.getStartDate());
		RouteBean routeBean=shipAdministrator.viewByRouteId(scheduleBean.getRouteID());
		reservation.setTotalFare(routeBean.getFare()*(Integer)session.getAttribute("seats"));
		String status=shipAdministrator.reserve(reservation);
		session.setAttribute("reservationID",reservation.getReservationID());
		return "passengerDetails";
	}
	@RequestMapping(value="/passenger",method=RequestMethod.POST)
	public String passenger(@ModelAttribute CreditCardBean creditCardBean,@Valid @ModelAttribute PassengerBean passengerBean,BindingResult result,HttpSession session,Map<String,Object> map)
	{
		if(result.hasFieldErrors("name")||result.hasFieldErrors("age")||result.hasFieldErrors("gender"))
		{
			return "passengerDetails";
		}
		ReservationBean reservationBean=new ReservationBean();
		reservationBean.setReservationID((String)session.getAttribute("reservationID"));
		ArrayList<PassengerBean> passenger=new ArrayList<PassengerBean>();
		passengerBean.setScheduleID((String)session.getAttribute("scheduleID"));

		passenger.add(passengerBean);
		String status=shipAdministrator.reserveTicket(reservationBean,passenger);
		map.put("added","added");
		if((Integer)session.getAttribute("seats")!=1){
		session.setAttribute("seats",(Integer)session.getAttribute("seats")-1);
		return "passengerDetails";}
		else{
			return "pay";}
	}
	@RequestMapping(value="/payment",method=RequestMethod.POST)
	public String doPayment(@Valid @ModelAttribute CreditCardBean creditCardBean,BindingResult result,HttpSession session,Map<String,Object> map)
	{
		if(result.hasFieldErrors("creditCardNumber")||result.hasFieldErrors("validFrom")||result.hasFieldErrors("validTo")){
			return "pay";
			}
		String status=shipAdministrator.process(creditCardBean,session);
		if("creditCardNumber".equals(status))
		{
			map.put("cno","cno");
			return "pay";
		}
		if("wrong".equals(status))
		{
			map.put("card","card");
			return "pay";
		}
		
		if("validto".equals(status))
		{
			map.put("validto","validto");
			return "pay";
		}	
		if("validfrom".equals(status))
		{
			map.put("validfrom","validfrom");
			return "pay";
		}
		if("low".equals(status))
		{
			map.put("low","low");
			return "pay";
		}
		map.put("ticketno",(String)session.getAttribute("ticketno"));
		if("SUCCESS".equals(status))
		{
			
			return "reservationSuccess";
		}
		return "waitingList";
	}
	@RequestMapping(value="/cancelticket")
	public String cancel(@ModelAttribute ReservationBean reservationBean)
	{
		return "cancelTicket";
	}
	
	@RequestMapping(value="/cancel",method=RequestMethod.POST)
	public String doCancel(@Valid @ModelAttribute ReservationBean reservationBean,BindingResult result,Map<String,Object> map,HttpSession session)
	{
		if(result.hasFieldErrors("reservationID")){
			return "cancelTicket";
			}
		boolean uid=shipAdministrator.verify(reservationBean.getReservationID(),session);
			
		if(!uid)
		{
			map.put("invalid","invalid");
			return "cancelTicket";
		}

		boolean status=shipAdministrator.cancelTicket(reservationBean.getReservationID());
		if(!status)
		{
			map.put("notickets","notickets");
			return "cancelTicket";
		}
			return "cancelled";
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String doLogout(HttpSession session)
	{
		boolean status=user2.logout((String)session.getAttribute("userID"));
		session.invalidate();
		return "redirect:/start";
	}
	
	
	@RequestMapping(value="/viewticket")
	public String viewTicke(@ModelAttribute ReservationBean reservationBean)
	{
		return "ticketDetails";
	}
	
	@RequestMapping(value="/ticket")
	public String doView(@Valid @ModelAttribute ReservationBean reservationBean,BindingResult result,Map<String,Object> maps,HttpSession session)
	{
		
		if(result.hasFieldErrors("reservationID")){
			return "ticketDetails";
			}
		Map<ReservationBean,ArrayList<PassengerBean>> map=new HashMap<ReservationBean,ArrayList<PassengerBean>>();
		
		map=shipAdministrator.viewTicket(reservationBean.getReservationID());
		//if(map.size()==0)
		if(map.isEmpty())
		{
			
			maps.put("noticket","noticket");
			return "ticketDetails";
		}
		boolean uid=shipAdministrator.verify(reservationBean.getReservationID(),session);
		if(!uid)
		{
			maps.put("invalid","invalid");

			return "ticketDetails";
		}
		ArrayList<PassengerBean> pas=new ArrayList<PassengerBean>();
		for(ReservationBean key : map.keySet())
		{
			pas=map.get(key);
		}
		ScheduleBean scheduleBean=shipAdministrator.journey(pas.get(0).getScheduleID());
		maps.put("routemap",shipAdministrator.viewByRouteId(scheduleBean.getRouteID()));
		maps.put("shipmap",shipAdministrator.viewByShipId(scheduleBean.getShipID()));
		maps.put("passengermap",pas);
		Set<ReservationBean> set=map.keySet();
		List<ReservationBean> passengers=new ArrayList<ReservationBean>(set);
		maps.put("reservationmap",passengers.get(0));
		return "viewTicket";
	}
	@RequestMapping("/changepassword")
	public String password(@ModelAttribute CredentialsBean credentialsBean)
	{
		return "newpassword";
	}
	
	@RequestMapping("/password")
	public String passwordChange(@Valid @ModelAttribute CredentialsBean credentialsBean,BindingResult result,HttpServletRequest request,HttpSession session,Map<String,Object> map)
	{
		if(result.hasFieldErrors("password")){
			return "newpassword";}
		credentialsBean.setUserID((String)session.getAttribute("userID"));
		String Pass=request.getParameter("newPassword");
		String pwd=user2.changePassword(credentialsBean,Pass);
		if("INVALID".equals(pwd))
		{
			map.put("invalid","invalid");
			return "newpassword";
		}
		if("SUCCESS".equals(pwd))
		{
			map.put("success","success");
			return "newpassword";
		}
		return "newpassword";
	}
	@RequestMapping("/passwordAdmin")
	public String passwordChanges(@Valid @ModelAttribute CredentialsBean credentialsBean,BindingResult result,HttpServletRequest request,HttpSession session,Map<String,Object> map)
	{
		if(result.hasFieldErrors("password")){
			return "newpasswordAdmin";}
		credentialsBean.setUserID((String)session.getAttribute("userID"));
		String Pass=request.getParameter("newPassword");
		String pwd=user2.changePassword(credentialsBean,Pass);
		if("INVALID".equals(pwd))
		{
			map.put("invalid","invalid");
			return "newpasswordAdmin";
		}
		if("SUCCESS".equals(pwd))
		{
			map.put("success","success");
			return "newpasswordAdmin";
		}
		return "newpasswordAdmin";
	}
	@RequestMapping(value="/printTicket")
	public String print(@ModelAttribute ReservationBean reservationBean)
	{
		return "printid";
	}
	
	@RequestMapping(value="/print")
	public String doPrint(@Valid @ModelAttribute ReservationBean reservationBean,BindingResult result,Map<String,Object> maps,HttpSession session)
	{
		if(result.hasFieldErrors("reservationID")){
			return "ticketDetails";
			}
		Map<ReservationBean,ArrayList<PassengerBean>> map=new HashMap<ReservationBean,ArrayList<PassengerBean>>();
		
		map=shipAdministrator.viewTicket(reservationBean.getReservationID());
		//if(map.size()==0)
		if(map.isEmpty())
		{
			
			maps.put("noticketp","noticketp");
			return "printid";
		}
		boolean uid=shipAdministrator.verify(reservationBean.getReservationID(),session);
		if(!uid)
		{
			maps.put("invalidp","invalidp");

			return "printid";
		}
		session.setAttribute("ticketid",reservationBean.getReservationID());
		return "home";
	}
	
	 
	
	
}