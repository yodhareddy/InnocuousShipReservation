package com.wipro.srs.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.srs.bean.CreditCardBean;
import com.wipro.srs.bean.PassengerBean;
import com.wipro.srs.bean.ReservationBean;
import com.wipro.srs.bean.RouteBean;
import com.wipro.srs.bean.ScheduleBean;
import com.wipro.srs.bean.ShipBean;
import com.wipro.srs.dao.InnocuousShipDao;

@Service("shipAdministrator")
@Transactional
public class ShipAdministrator implements Administrator{
	@Autowired
	private InnocuousShipDao innocuousShipDao;
	
	public String addShip(ShipBean shipBean)
	{
		return innocuousShipDao.addShip(shipBean);
	}
	public int removeShip(ShipBean shipBean)
	{
		return innocuousShipDao.removeShip(shipBean);
	}
	public boolean modifyShip(ShipBean shipBean)
	{
		return innocuousShipDao.modifyShip(shipBean);
	}
	public List<ShipBean> viewByAllShips()
	{
		return innocuousShipDao.viewByAllShips();
	}
	@Override
	public String addRoute(RouteBean routeBean) {
		// TODO Auto-generated method stub
		return innocuousShipDao.addRoute(routeBean);
	}
	@Override
	public int removeRoute(RouteBean routeBean) {
		// TODO Auto-generated method stub
		return innocuousShipDao.removeRoute(routeBean);
	}
	@Override
	public boolean modifyRoute(RouteBean routeBean) {
		
		return innocuousShipDao.modifyRoute(routeBean);
	}
	@Override
	public List<RouteBean> viewByAllRoute() {
		
		return innocuousShipDao.viewByAllRoute();
	}
	@Override
	public boolean modifySchedule(ScheduleBean scheduleBean) {
		// TODO Auto-generated method stub
		return innocuousShipDao.modifySchedule(scheduleBean);
	}
	@Override
	public List<ScheduleBean> viewByAllSchedule() {
		// TODO Auto-generated method stub
		return innocuousShipDao.viewByAllSchedule();
	}
	@Override
	public String addSchedule(ScheduleBean scheduleBean) {
		// TODO Auto-generated method stub
		return innocuousShipDao.addSchedule(scheduleBean);
	}
	@Override
	public int removeSchedule(ScheduleBean scheduleBean) {
		// TODO Auto-generated method stub
		return innocuousShipDao.removeSchedule(scheduleBean);
	}
	public ShipBean viewByShipId(String shipID) {
		
		return innocuousShipDao.viewByShipId(shipID);
	}
	@Override
	public RouteBean viewByRouteId(String routeID) {
		
		return innocuousShipDao.viewByRouteId(routeID);
	}
	@Override
	public ScheduleBean viewByScheduleId(String scheduleID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.viewByScheduleId(scheduleID);
	}
	@Override
	public ArrayList<ScheduleBean> viewScheduleByRoute(String source,
			String destination, Date  journeyDate) {
		return innocuousShipDao.viewScheduleByRoute(source,destination,journeyDate);
	}
	@Override
	public String reserve(ReservationBean reservation) {
		// TODO Auto-generated method stub
		return innocuousShipDao.reserve(reservation);
	}
	public String reserveTicket(ReservationBean reservationBean,
			ArrayList<PassengerBean> passenger) {
		// TODO Auto-generated method stub
		return innocuousShipDao.reserveTicket(reservationBean,passenger);
	}
	public String process(CreditCardBean creditCardBean,HttpSession session) {
		// TODO Auto-generated method stub
		return innocuousShipDao.process(creditCardBean,session);
	}
	@Override
	public boolean cancelTicket(String reservationID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.cancelTicket(reservationID);
	}
	public ArrayList<PassengerBean> viewPassengersByShip(String scheduleID) {
		return innocuousShipDao.viewPassengersByShip(scheduleID);
	}
	@Override
	public int capacity(String sid) {
		// TODO Auto-generated method stub
		return innocuousShipDao.capacity(sid);
	}
	public Map<ReservationBean, ArrayList<PassengerBean>> viewTicket(
			String reservationID) {
		
		return innocuousShipDao.viewTicket(reservationID);
	}
	public ScheduleBean journey(String scheduleID) {
		
		return innocuousShipDao.journey(scheduleID);
	}
	public boolean verify(String reservationID, HttpSession session) {
		// TODO Auto-generated method stub
		return innocuousShipDao.verify(reservationID,session);
	}
	@Override
	public boolean updateBalanceShip(String shipID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.updateBalanceShip(shipID);
	}
	@Override
	public boolean updateBalanceRoute(String routeID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.updateBalanceRoute(routeID);
	}
	@Override
	public boolean updateBalanceSchedule(String scheduleID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.updateBalanceSchedule(scheduleID);
	}
	@Override
	public List<PassengerBean> getTicket(String reservationID) {
		// TODO Auto-generated method stub
		return innocuousShipDao.getTicket(reservationID);
	}
}
